Version and Helper Functions
----------------------------

.. automodule:: periphery
    :members: __version__, version, sleep, sleep_ms, sleep_us
    :undoc-members:
    :show-inheritance:

