#if defined _WIN32 || defined __CYGWIN__
#define DLL_PUBLIC __declspec(dllexport)
#else
#define DLL_PUBLIC
#endif

int DLL_PUBLIC foo(void) {
  return 0;
}
