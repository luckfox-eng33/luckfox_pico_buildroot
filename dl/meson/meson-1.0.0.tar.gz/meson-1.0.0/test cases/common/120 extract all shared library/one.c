#include"extractor.h"

int func1(void) {
    return 1;
}
