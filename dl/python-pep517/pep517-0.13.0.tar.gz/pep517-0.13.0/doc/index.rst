pep517
======

This package provides an API to call the hooks defined in :pep:`517`.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   callhooks
   changelog



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
