To cut a release, use
`bump2version <https://github.com/c4urself/bump2version>`_,
the `preferred version
<https://github.com/peritus/bumpversion/pull/58#issuecomment-428956095>`_
of bumpversion. Something like:

    bump2version minor

Then push the commit and tags to GitHub.
