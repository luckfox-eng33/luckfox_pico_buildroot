from setuptools import setup

setup(
    name='pep517-test-setup-py-support',
    version='1.0'
)
