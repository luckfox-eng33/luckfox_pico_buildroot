"""Internal package, containing launcher templates for ``installer.scripts``."""
