```{caution}
This API is not finalised, and may change in a patch version.
```

# `installer`

```{eval-rst}
.. autofunction:: installer.install
```
