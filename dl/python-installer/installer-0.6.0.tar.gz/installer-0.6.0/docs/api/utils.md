```{caution}
This API is not finalised, and may change in a patch version.
```

# `installer.utils`

```{eval-rst}
.. automodule:: installer.utils
    :members:
```
