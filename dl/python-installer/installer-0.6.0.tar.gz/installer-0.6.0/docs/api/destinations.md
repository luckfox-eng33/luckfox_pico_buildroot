```{caution}
This API is not finalised, and may change in a patch version.
```

# `installer.destinations`

```{eval-rst}
.. automodule:: installer.destinations

.. autoclass:: installer.destinations.WheelDestination
    :members:

.. autoclass:: installer.destinations.SchemeDictionaryDestination()
    :members:
    :special-members: __init__
```
